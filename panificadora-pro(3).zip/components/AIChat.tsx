import React from 'react';

// Este componente ha sido desactivado para la versión estática
const AIChat: React.FC = () => {
  return null;
};

export default AIChat;