// Servicio desactivado para la versión estática
export const hasApiKey = false;
export function createBakerChat() { return null; }
export async function diagnoseBreadImage() { return ""; }